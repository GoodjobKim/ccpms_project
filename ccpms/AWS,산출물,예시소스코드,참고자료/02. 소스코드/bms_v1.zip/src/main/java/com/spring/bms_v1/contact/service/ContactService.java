package com.spring.bms_v1.contact.service;

import com.spring.bms_v1.contact.dto.ContactDTO;

public interface ContactService {

	public void addNewContact(ContactDTO contactDTO) throws Exception;
	
}
