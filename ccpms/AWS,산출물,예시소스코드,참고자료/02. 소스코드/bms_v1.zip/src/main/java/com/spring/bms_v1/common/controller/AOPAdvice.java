package com.spring.bms_v1.common.controller;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AOPAdvice {
	
	// to do

}
